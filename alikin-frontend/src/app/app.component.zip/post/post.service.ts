import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Page } from '../shared/models/page.model'; // si usas paginación genérica
import {environment} from "../../enviroments/enviroment";
import {PostResponse} from "./post.model";

@Injectable({
  providedIn: 'root'
})
export class PostService {
  private apiUrl = `${environment.apiUrl}/posts/upload`; // cambiamos a endpoint que acepta multipart

  constructor(private http: HttpClient) {}

  createPost(formData: FormData): Observable<any> {
    return this.http.post<any>(this.apiUrl, formData);
  }

  getFeed(page: number, size: number): Observable<Page<PostResponse>> {
    const params = new HttpParams()
      .set('page', page)
      .set('size', size);

    return this.http.get<Page<PostResponse>>(`${environment.apiUrl}/posts/feed`, { params });
  }
}
