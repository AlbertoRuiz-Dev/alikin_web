import { HttpClient } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import {PostResponse} from "../post.model";

@Component({
  selector: 'app-post-item',
  templateUrl: './post-item.component.html',
  styleUrls: ['./post-item.component.scss']
})
export class PostItemComponent {
  @Input() post!: PostResponse;

  constructor(private http: HttpClient) {
    this.post = {
      ...this.post,
      isHighlighted: this.post.isHighlighted ?? false,
      isExpanded: this.post.isExpanded ?? false
    };
  }

  upvote(post: PostResponse): void {
    const newVote = post.userVote === 1 ? 0 : 1;
    this.http.post(`/api/posts/${post.id}/vote`, { vote: newVote }).subscribe({
      next: (response: any) => {
        post.userVote = newVote;
        post.voteCount = response.voteCount;
      },
      error: (err) => console.error('Upvote failed', err)
    });
  }

  downvote(post: PostResponse): void {
    const newVote = post.userVote === -1 ? 0 : -1;
    this.http.post(`/api/posts/${post.id}/vote`, { vote: newVote }).subscribe({
      next: (response: any) => {
        post.userVote = newVote;
        post.voteCount = response.voteCount;
      },
      error: (err) => console.error('Downvote failed', err)
    });
  }
}
