import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PostResponse } from '../post/post.model';
import { environment } from '../../enviroments/enviroment';

@Component({
  selector: 'app-feed',
  templateUrl: './feed.component.html',
  styleUrls: ['./feed.component.scss']
})
export class FeedComponent implements OnInit {
  posts: PostResponse[] = [];
  loading = false;
  allLoaded = false;
  page = 0; // Cambiado a 0, ya que la API probablemente usa índices basados en 0
  error: string | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadPosts();
  }

  loadPosts(): void {
    if (this.loading || this.allLoaded) return;
    this.loading = true;
    this.error = null;

    const url = `${environment.apiUrl}/posts/feed?page=${this.page}`;
    console.log('Fetching posts from:', url);
    this.http.get<{ content: PostResponse[], totalPages: number, last: boolean }>(url).subscribe({
      next: (response) => {
        console.log('API response:', response);
        const newPosts = response.content || [];
        if (!Array.isArray(newPosts) || newPosts.length === 0 || response.last) {
          this.allLoaded = true;
        } else {
          this.posts = [...this.posts, ...newPosts.map(post => ({
            ...post,
            isHighlighted: post.voteCount > 100,
            isExpanded: false
          }))];
          this.page++;
        }
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading posts:', err);
        this.error = 'No se pudieron cargar los posts. Mostrando datos de prueba...';
        this.loading = false;
        // Datos de prueba
        this.posts = [
          ...this.posts,
          {
            id: 1,
            content: '¡Post de prueba para verificar el feed!',
            user: { id: 1, name: 'Usuario', nickname: 'user1', profilePictureUrl: '/assets/default-avatar.png' },
            createdAt: new Date().toISOString(),
            voteCount: 150,
            userVote: 0,
            commentsCount: 5,
            isHighlighted: true,
            isExpanded: false
          },
          {
            id: 2,
            content: 'Otro post de prueba con una imagen.',
            imageUrl: 'https://via.placeholder.com/600x400',
            user: { id: 2, name: 'Usuario 2', nickname: 'user2', profilePictureUrl: '/assets/default-avatar.png' },
            createdAt: new Date(Date.now() - 3600000).toISOString(),
            voteCount: 50,
            userVote: 0,
            commentsCount: 2,
            isHighlighted: false,
            isExpanded: false
          }
        ];
      }
    });
  }

  onScroll(): void {
    this.loadPosts();
  }
}
